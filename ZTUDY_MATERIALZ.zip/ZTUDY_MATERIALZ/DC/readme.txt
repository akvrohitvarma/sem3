Annotated folder 
	-has PDFs with sir's annotations and explanations

Unannotated folder 
	-has just pure PDF without any annotation, any annotation found is omitted